#pragma once


class EspStationClass
{
    public:
        void init();
        bool isStationOnline();
        
    private:
};
extern EspStationClass EspStation;