#pragma once

class EspApClass
{
    public:
        EspApClass();
        void init();
        bool isApStarted();
        
    private:
};
extern EspApClass EspAp;
